# DL2021FinalReport

This is the latex for the final report and presentation. 

Files ```*.tex``` are for each section. 
Using command ```make``` to generate the final pdf.
